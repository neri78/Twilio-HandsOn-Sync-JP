window.addEventListener('load', () => {

    // HTML要素
    const participate = document.getElementById('participate');
    const alertForm = document.getElementById('alert-form');
    const messageDiv = document.getElementById('message-div');
    const messageField = document.getElementById('message');

    //Twilio functionsがデプロイされたURL
    const url = '';
    let syncClinet;

    // 発信・受信ボタンがクリックされた際のイベントリスナー
    participate.addEventListener('click', async (event) => {

    })

    // アラート情報を送るフォームがサブミットされた際のイベントリスナー
    alertForm.addEventListener('submit', async (event) => {
        
    });
});